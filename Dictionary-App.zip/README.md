#DICTIONARY APP (USING JAVA)

1. Description

    - Our English dictionary project is a simple Java application designed to allow users to look up words and phrases in English to find definitions and usage examples. 
In addition, users can learn and play small games to remember words better.

2. How to use
    
    - Using this application is very simple. First, download the project to your machine, then run the program. 
    - Enter the word you want to look up into the search box and press the search button to display the definition of that word. 
    - We have added some games to help you remember vocabulary better, give it a try!
3. Project Structure
4. Libraries and Tools Used
